package com.example.lostperson;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button Lost;
    Button Found;
    Button LostList;
    Button FoundList;
    TextView Contact;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Lost = findViewById(R.id.buttonlost);
        Lost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,ReportLostPerson.class);
                startActivity(intent);

            }
        });

        Found = findViewById(R.id.buttonfound);
        Found.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,ReportFoundPerson.class);
                startActivity(intent);
            }
        });

        FoundList = findViewById(R.id.checkfoundperson);
        FoundList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,CheckFoundPersons.class);
                startActivity(intent);
            }
        });
        LostList = findViewById(R.id.checklostfound);
        LostList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,CheckLostPersons.class);
                startActivity(intent);
            }
        });
        Contact = findViewById(R.id.contact);
        Contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,ContactUs.class);
                startActivity(intent);
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
       MenuInflater inflater= getMenuInflater();
         inflater.inflate(R.menu.main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

            int id = item.getItemId();

            if(id==R.id.action_settings){
                return true;
            }
            else if(id==R.id.action_Logout)
            {
                Intent intent =new Intent(MainActivity.this,Login.class);
                startActivity(intent);
                return true;
            }
        return super.onOptionsItemSelected(item);
    }
}