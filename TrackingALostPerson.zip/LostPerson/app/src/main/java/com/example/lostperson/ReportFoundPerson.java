package com.example.lostperson;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.vishnusivadas.advanced_httpurlconnection.PutData;

public class ReportFoundPerson extends AppCompatActivity {

    EditText Name,Gender,Age,Date,Time,Address,Number,Marks;
    Button submit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_found_person);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Name = findViewById(R.id.editTextTextPersonName);
        Gender = findViewById(R.id.editTextTextGender);
        Age= findViewById(R.id.editTextTextAge);
        Date = findViewById(R.id.editTextTextDate);
        Time = findViewById(R.id.editTextTextTime);
        Address= findViewById(R.id.editTextTextAdress);
        Number = findViewById(R.id.editTextNumber);
        Marks = findViewById(R.id.editTextmarks);
        submit = findViewById(R.id.submitfound);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name, gender,age,date,time,address,number,marks;

                name= String.valueOf(Name.getText());
                gender = String.valueOf(Gender.getText());
                age= String.valueOf(Age.getText());
                date =String.valueOf(Date.getText());
                time = String.valueOf(Time.getText());
                address = String.valueOf(Address.getText());
                number= String.valueOf(Number.getText());
                marks = String.valueOf(Marks.getText());

                if(!name.equals("") && !gender.equals("") && !age.equals("") && !date.equals("") && !time.equals("") && !address.equals("") && !number.equals("") && !marks.equals("") ) {

                    //Start ProgressBar first (Set visibility VISIBLE)
                    Handler handler = new Handler(Looper.getMainLooper());
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            //Starting Write and Read data with URL
                            //Creating array for parameters
                            String[] field = new String[8];
                            field[0] = "name";
                            field[1] = "gender";
                            field[2] = "age";
                            field[3] = "date";
                            field[4] = "time";
                            field[5] = "address";
                            field[6] = "number";
                            field[7] = "marks";
                            //Creating array for data
                            String[] data = new String[8];
                            data[0] = name;
                            data[1] = gender;
                            data[2] = age;
                            data[3] = date;
                            data[4] = time;
                            data[5] = address;
                            data[6] = number;
                            data[7] = marks;
                            PutData putData = new PutData("http://192.168.74.106/LostPerson/reportfoundperson.php", "POST", field, data);
                            if (putData.startPut()) {
                                if (putData.onComplete()) {
                                    String result = putData.getResult();
                                    //End ProgressBar (Set visibility to GONE)
                                    if(result.equals("Submitted Successfully")){
                                        Intent intent  = new Intent(getApplicationContext(),MainActivity.class);
                                        startActivity(intent);
                                        finish();

                                        Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();
                                    }
                                    else
                                    {
                                        Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();
                                    }

                                }
                            }
                            //End Write and Read data with URL
                        }
                    });
                }
                else{
                    Toast.makeText(getApplicationContext(),"All fields are Required",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}