package com.example.lostperson;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface apiset {
    @GET("json_fetch.php")
    Call<List<ResponseModel>> getdata();
}
